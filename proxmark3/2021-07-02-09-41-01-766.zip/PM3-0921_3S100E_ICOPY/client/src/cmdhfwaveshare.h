//-----------------------------------------------------------------------------
// Waveshare commands
//-----------------------------------------------------------------------------

#ifndef CMDHFWAVESHARE_H__
#define CMDHFWAVESHARE_H__

int CmdHFWaveshare(const char *Cmd);

#endif
