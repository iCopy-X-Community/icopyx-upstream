#ifndef HASH1_BRUTE_H
#define HASH1_BRUTE_H
void brute_hash1(void);

#endif // HASH1_BRUTE_H
